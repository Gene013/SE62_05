<?php
session_start();
?>

<div class="container-fluid" align="center">
    <div>
        <br>
        <h2 align = 'center'>เพิ่มผู้ใช้</h2>
        <br>
    </div>
    <form method="post" action="index.php?controller=admin&action=addUser">
        <div class="container p-3 my-3 border" style="-webkit-box-flex: 0;
      -ms-flex: 0 0 calc(100% - 10px);
      flex: 0 0 calc(100% - 10px);
      max-width: calc(100% - 10px);
      width: calc(100% - 10px); } }">
            <div class="row">
                <div class="col-sm-6">
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text">บัญชีผู้ใช้</span>
                        </div>
                        <input type="text" class="number form-control" id="username" name="username">
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text">ชื่อ-นามสกุล</span>
                        </div>
                        <input type="text" class="form-control" id="name" name="name">
                    </div>
                </div>
            </div>
            <div class="row" id="name">
                <div class="col-sm-6">
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text">E-mail</span>
                        </div>
                        <input type="text" class="form-control" id="mail" name="mail">
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <label class="input-group-text" for="serial">ประเภทผู้ใช้</label>
                        </div>
                        <select class="custom-select" id="role" name="role">
                            <option selected>Choose...</option>
                            <option value='ADMIN'>ADMIN</option>
                            <option value='TEACHER'>TEACHER</option>
                        </select>
                    </div>
                </div>
            </div>
            <div align='center'>
                <button class="btn btn-primary" type="submit">ยืนยัน</button>&nbsp
                <a href="index.php?controller=admin&action=ManageUser" class="btn btn-danger">ยกเลิก</a>
            </div>
        </div>
    </form>
</div>
</div>