<?php
session_start();

class StudentsController{
    public function borrow(){
        $equipList = equipment::getAll();
        $teacherList = teacher::getAll();
        require_once ('Views/students/borrow.php');
    }
    public  function checkStatus(){
        $std_id = substr($_SESSION['ldap_uid'],1,10);
        $orderid = $_POST['orderID'];
        $orderStatus = order::getStatus($std_id);
        $orderDetail = order::getOrderDetail($orderid);
        require_once ('Views/students/checkStatus.php');
    }
    public  function borrowEquip(){
        $name = $_SESSION['ldap_thainame'];
        $std_id = substr($_SESSION['ldap_uid'],1,10);
        $mail = $_SESSION['ldap_email'];
        $dateStart = $_POST['dateStart'];
        $dateEnd = $_POST['dateEnd'];
        $reason = $_POST['reason'];
        $project_name = $_POST['project_name'];
        $teacher = $_POST['teacher'];
        $cart = $_SESSION['cart'];
        order::addOrder($name,$std_id,$mail,$dateStart,$dateEnd,$reason,$project_name,$teacher,$cart);
        require_once ('sendemailborrow.php');
        StudentsController::checkStatus();
    }
}
?>