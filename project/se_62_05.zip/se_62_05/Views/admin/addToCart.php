<?php
session_start();
$action = $_POST['action'];
if($action=="addToCart"){
    $serial = $_POST['serial'];
    $s_serial = $_POST['s_serial'];
    echo "<script>console.log('$action')</script>";
    echo "<script>console.log('$serial')</script>";
    echo "<script>console.log('$s_serial')</script>";
    $_SESSION['cart'][] = array(
        0 => $_POST['serial'],
        1 => $_POST['s_serial'],
    );
    print_r($_SESSION['cart']);
}elseif ($action=="getCart"){
    $output = "";
    if (isset($_SESSION['cart'])&&count($_SESSION['cart']>0)){
        for ($i=0;$i<count($_SESSION['cart']);$i++){
            $output.= "<tr>
                               <td align='center'>{$_SESSION['cart'][$i][0]}</td> 
                               <td align='center'>{$_SESSION['cart'][$i][1]}</td>
                           </tr>";
        }
    }else{
        $output.= "<tr><td align='center' colspan='2'><b>----------- กรุณาเพิ่มเลขครุภัณฑ์ย่อย -----------</b></td></tr>*0";
    }
    echo $output;
}elseif ($action=="editCart"){
    unset($_SESSION['cart']);
}
?>