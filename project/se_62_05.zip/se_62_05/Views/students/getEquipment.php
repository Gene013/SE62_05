<?php
require ('../../connect/db_connect.php');
if (isset($_GET['type_id'])){
    $type_id = $_GET['type_id'];
    $sql = 'SELECT equipment.id,equipment.name_equ FROM equipment INNER JOIN type ON equipment.type_equ=type.id WHERE equipment.type_equ="'.$type_id.'"';
    $equipment = array();
    if($result = mysqli_query($conn,$sql)){
        while($row = mysqli_fetch_assoc($result)){
            array_push($equipment,$row);
        }
    }
}
echo json_encode($equipment);
?>