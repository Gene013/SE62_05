<?php
    session_start();
    $action = $_POST['action'];
    if($action=="addToCart"){
        $name = $_POST['name'];
        $serial = $_POST['serial'];
        echo "<script>console.log('$action')</script>";
        echo "<script>console.log('$name')</script>";
        echo "<script>console.log('$serial')</script>";
        $_SESSION['cart'][] = array(
            0 => $_POST['name'],
            1 => $_POST['serial'],
        );
        print_r($_SESSION['cart']);
    }elseif ($action=="getCart"){
        $output = "";
        if (isset($_SESSION['cart'])&&count($_SESSION['cart']>0)){
            for ($i=0;$i<count($_SESSION['cart']);$i++){
                $output.= "<tr>
                               <td>{$_SESSION['cart'][$i][0]}</td> 
                               <td align='center'>{$_SESSION['cart'][$i][1]}</td>
                           </tr>";
            }
        }else{
            $output.= "<tr><td align='center' colspan='2'><b>----------- กรุณาเลือกรายการ -----------</b></td></tr>*0";
        }
        echo $output;
    }elseif ($action=="editCart"){
        unset($_SESSION['cart']);
    }
?>