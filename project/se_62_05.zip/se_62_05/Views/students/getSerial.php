<?php
require ('../../connect/db_connect.php');
if (isset($_GET['equ_id'])){
    $equ_id = $_GET['equ_id'];
    $sql = 'SELECT equiment_detail.id,equipment.serial_number,equiment_detail.serial,equiment_detail.status FROM equiment_detail INNER JOIN equipment ON equiment_detail.equ_id = equipment.id WHERE equipment.name_equ LIKE "'.$equ_id.'"';
    $serial = array();
    if($result = mysqli_query($conn,$sql)){
        while($row = mysqli_fetch_assoc($result)){
            array_push($serial,$row);
        }
    }
}
//print_r($serial);
echo json_encode($serial);
?>