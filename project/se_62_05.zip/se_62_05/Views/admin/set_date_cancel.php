<?php
session_start();

if (isset($_SESSION["Logon"]) && $_SESSION["Logon"] == 1) {
    $ldap_uid = $_SESSION["ldap_uid"];
    $ldap_engname = $_SESSION["ldap_engname"];
    $ldap_thainame = $_SESSION["ldap_thainame"];
    $ldap_email = $_SESSION["ldap_email"];
    $ldap_gender = $_SESSION["ldap_gender"];
    $ldap_Job = $_SESSION["ldap_Job"];
    $ldap_position = $_SESSION["ldap_position"];
    $ldap_department = $_SESSION["ldap_department"];
    $ldap_faculty = $_SESSION["ldap_faculty"];
    $ldap_campus = $_SESSION["ldap_campus"];
    $ldap_Status = $_SESSION["ldap_Status"];
    $ldap_idcode = $_SESSION["ldap_idcode"];
} elseif (isset($_SESSION["Logon"]) && $_SESSION["Logon"] == 2) {
    $ldap_thainame = $_SESSION["ldap_thainame"];
    $ldap_Status = $_SESSION["ldap_Status"];
}else{
    header('location:form_login.php');
}

//ตั้งค่าการเชื่อมต่อฐานข้อมูล
$database_host 			= 'localhost';
$database_username 		= 'se62_05';
$database_password 		= 'se62_05';
$database_name 			= 'se62_05';

$mysqli = new mysqli($database_host, $database_username, $database_password, $database_name);
//กำหนด charset ให้เป็น utf8 เพื่อรองรับภาษาไทย
$mysqli->set_charset("utf8");

//กรณีมี Error เกิดขึ้น
if ($mysqli->connect_error) {
    die('Error : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
}
$mount = date("m");
$year = date("Y");
$dateStart = date("Y-m-d");
$DayOfWeek = date("w", strtotime($dateStart));
for($i = 0;$DayOfWeek!=0;$i++ ){
    $dateStart = date("Y-m-d",strtotime($dateStart."-1 day"));
    $DayOfWeek = date("w", strtotime($dateStart));
}
$dateEnd = date("Y-m-d",strtotime($dateStart."+6 day"));;

$get_data = $mysqli->query("SELECT * FROM  date_cancel");


while($data = $get_data->fetch_assoc()){

    $id = $data['id'];
    $num = $data['num_date'];
}
?>
<div class="container-fluid" align="center">
    <div>
        <br><h2 align="center">กำหนดจำนวนวันที่มารับอุปกรณ์</h2><br>
    </div>
    <div class="container p-3 my-3 border" style="-webkit-box-flex: 0;
      -ms-flex: 0 0 calc(100% - 10px);
      flex: 0 0 calc(100% - 10px);
      max-width: calc(100% - 10px);
      width: calc(100% - 10px); } }">

        <form id="editDateCancel" method="post" action="index.php?controller=admin&action=editDate">
            <input type="hidden" id="id" name="id" value="<?php echo "$id";?>">
            <div  class="row">

                    <div class="input-group-prepend">
                            <span class="input-group-text">จำนวนวัน</span>
                        </div>
                        <input type="text"  id="num" name="num" value="<?php echo "$num";?>">
                    </div>
                </div>
            </div>
            <div align='center'>
                <button class="btn btn-primary" type="submit">ยืนยัน</button>&nbsp;
                <button class="btn btn-danger">ยกเลิก</button>
            </div>
        </form>
    </div>
</div>





</div>