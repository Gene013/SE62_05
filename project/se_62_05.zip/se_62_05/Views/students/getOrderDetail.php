<?php
$orderID = $_POST['orderID'];
echo "55555555555555555555555555555555555555555555555";
/*require('connect/db_connect.php');
$sql = 'SELECT orders.id,equipment.name_equ,equipment.serial_number,equiment_detail.serial FROM orders INNER JOIN order_detail ON order_detail.order_id=orders.id INNER JOIN equiment_detail ON equiment_detail.id = order_detail.equ_detail_id INNER JOIN equipment ON equipment.id=equiment_detail.equ_id WHERE orders.id=1';
$orderDetail = array();
if ($result = mysqli_query($conn, $sql)) {
    while ($row = mysqli_fetch_assoc($result)) {
        array_push($orderDetail, $row);
    }
}
echo json_encode($orderDetail);


