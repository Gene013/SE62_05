<?php
session_start();
unset($_SESSION['cart']);

if (isset($_SESSION["Logon"]) && $_SESSION["Logon"] == 1) {
    $ldap_uid = $_SESSION["ldap_uid"];
    $ldap_engname = $_SESSION["ldap_engname"];
    $ldap_thainame = $_SESSION["ldap_thainame"];
    $ldap_email = $_SESSION["ldap_email"];
    $ldap_gender = $_SESSION["ldap_gender"];
    $ldap_Job = $_SESSION["ldap_Job"];
    $ldap_position = $_SESSION["ldap_position"];
    $ldap_department = $_SESSION["ldap_department"];
    $ldap_faculty = $_SESSION["ldap_faculty"];
    $ldap_campus = $_SESSION["ldap_campus"];
    $ldap_Status = $_SESSION["ldap_Status"];
    $ldap_idcode = $_SESSION["ldap_idcode"];
    echo "<script>console.log('id $ldap_uid')</script>";
    echo "<script>console.log('thainame $ldap_thainame')</script>";
    echo "<script>console.log('engname $ldap_engname')</script>";
    echo "<script>console.log('status $ldap_Status')</script>";
} elseif (isset($_SESSION["Logon"]) && $_SESSION["Logon"] == 2) {
    $ldap_thainame = $_SESSION["ldap_thainame"];
    $ldap_Status = $_SESSION["ldap_Status"];
} else {
    header('location:form_login.php');
}
?>
<div class="container-fluid" align="center">
    <div>
        <br>
        <h2 align="center">จัดการผู้ใช้</h2><br>
    </div>
    <div class="container p-3 my-3 border" style="-webkit-box-flex: 0;
      -ms-flex: 0 0 calc(100% - 10px);
      flex: 0 0 calc(100% - 10px);
      max-width: calc(100% - 10px);
      width: calc(100% - 10px); } }">
        <div align="right"><a style="color: white" class="btn btn-primary" href="index.php?controller=admin&action=ManageUserExternal">จัดการผู้ใช้ภายนอก</a>&nbsp;<a style="color: white" class="btn btn-primary" href="index.php?controller=admin&action=formUser">เพิ่มผู้ใช้</a></div><br>
        <div>
            <table class='table table-striped table-bordered' style='width:100%' id='borlist'>
                <thead>
                <tr align="center">
                    <th>บัญชีผู้ใช้</th>
                    <th>ชื่อ-นามสกุล</th>
                    <th>Email</th>
                    <th>ประเภาทผู้ใช้</th>
                    <th>การจัดการ</th>
                </tr>
                </thead>
                <tbody>
                    <?php foreach ($UserList as $user){ echo "
                    <tr>
                        <td>$user->username</td>
                        <td>$user->name</td>
                        <td>$user->mail</td>
                        <td>$user->role</td>
                        <form method='post' action='index.php?controller=admin&action=editUser'>
                            <input type='hidden' value='$user->id' name='id'>
                            <td align='center'><button class='btn btn-warning'>แก้ไข</button>&nbsp;<a style='color: white' class='btn btn-danger' href='index.php?controller=admin&action=removeUser&u=$user->id'>ลบ</a></td>
                        </form>
                    </tr>
                    ";} ?>
                </tbody>
            </table>

        </div>
    </div>
    <script type="text/javascript">
        $(document).ready(function() {
            $('#borlist').DataTable();
        } );

    </script>

