<div class="container-fluid" align="center">
    <div>
        <br><h2 align="center">เพิ่มหมวดหมู่</h2><br>
    </div>
    <div class="container p-3 my-3 border" style="-webkit-box-flex: 0;
      -ms-flex: 0 0 calc(100% - 10px);
      flex: 0 0 calc(100% - 10px);
      max-width: calc(100% - 10px);
      width: calc(100% - 10px); } }">

        <form id="addType" method="post" action="index.php?controller=admin&action=addType">
            <div  class="row">
                <div class="input-group mb-4">
                </div>
                <div class="input-group mb-4">
                    <div class="input-group-prepend">
                        <span class="input-group-text">ชื่อหมวดหมู่</span>
                    </div>
                    <input type="text" class="text form-control" id="type_name" name="type_name">
                </div>
            </div>
    </div>
</div>
<div align='center'>
    <button class="btn btn-primary" type="submit">ยืนยัน</button>&nbsp;
    <button class="btn btn-danger">ยกเลิก</button>
</div>
</form>
</div>
</div>

</div>