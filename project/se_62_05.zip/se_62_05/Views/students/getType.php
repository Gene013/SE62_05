<?php
    require ('../../connect/db_connect.php');
    $sql = 'SELECT * FROM `type`';
    $type = array();
    if($result = mysqli_query($conn,$sql)){
        while($row = mysqli_fetch_assoc($result)){
            array_push($type,$row);
        }
    }
    echo json_encode($type);
?>