<?php
session_start();
unset($_SESSION['cart']);

if (isset($_SESSION["Logon"]) && $_SESSION["Logon"] == 1) {
    $ldap_uid = $_SESSION["ldap_uid"];
    $ldap_engname = $_SESSION["ldap_engname"];
    $ldap_thainame = $_SESSION["ldap_thainame"];
    $ldap_email = $_SESSION["ldap_email"];
    $ldap_gender = $_SESSION["ldap_gender"];
    $ldap_Job = $_SESSION["ldap_Job"];
    $ldap_position = $_SESSION["ldap_position"];
    $ldap_department = $_SESSION["ldap_department"];
    $ldap_faculty = $_SESSION["ldap_faculty"];
    $ldap_campus = $_SESSION["ldap_campus"];
    $ldap_Status = $_SESSION["ldap_Status"];
    $ldap_idcode = $_SESSION["ldap_idcode"];
    echo "<script>console.log('id $ldap_uid')</script>";
    echo "<script>console.log('thainame $ldap_thainame')</script>";
    echo "<script>console.log('engname $ldap_engname')</script>";
    echo "<script>console.log('status $ldap_Status')</script>";
} elseif (isset($_SESSION["Logon"]) && $_SESSION["Logon"] == 2) {
    $ldap_thainame = $_SESSION["ldap_thainame"];
    $ldap_Status = $_SESSION["ldap_Status"];
} else {
    header('location:form_login.php');
}
?>

<div class="container-fluid" align="center">
    <div>
        <br>
        <h2 align="center">เช็คสถานะการยืม</h2><br>
    </div>
    <div class="container p-3 my-3 border" style="-webkit-box-flex: 0;
      -ms-flex: 0 0 calc(100% - 10px);
      flex: 0 0 calc(100% - 10px);
      max-width: calc(100% - 10px);
      width: calc(100% - 10px); } }">
        <div>

            <table class='table table-striped table-bordered' style='width:100%' id='borlist'>
                <thead>
                <tr align="center">
                    <th>เลขที่ใบยืม</th>
                    <th>วันที่เริ่มยืม</th>
                    <th>กำหนดส่งคืน</th>
                    <th>สถานะใบยืม</th>
                    <th>การจัดการ</th>
                </tr>
                </thead>
                <tbody>
                <?php
                print_r($orderDetail);
                foreach ($orderStatus as $order) {
                    echo "<tr><td align='center'>$order->id</td>
                            <td align='center'>$order->date_start</td>
                            <td align='center'>$order->date_end</td>
                            <td align='center'>$order->status_name</td>
                            
                            <td align='center'><a href='./orderDetail.php?orderId=".$order->id."' style='color: white' class='btn btn-primary' data-toggle='modal' data-target='#ModelDetail'>รายละเอียดใบจอง</a>&nbsp;&nbsp;<a id='c' class='btn btn-danger'>ยกเลิกการยืม</a></td>
                            </tr>";

                }


                ?>
                </tbody>
            </table>
            <div class="modal fade" id="ModelDetail1" tabindex="-1" role="dialog"
                 aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div align="center" class="modal-header">
                            <h5 class="modal-title" id="exampleModalScrollableTitle">รายละเอียดใบจอง</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="container p-3 my-3 border" style="-webkit-box-flex: 0;
      -ms-flex: 0 0 calc(100% - 10px);
      flex: 0 0 calc(100% - 10px);
      max-width: calc(100% - 10px);
      width: calc(100% - 10px); } }">
                                <div class="row">
                                    <table class='table table-striped table-bordered' style='width:100%' id='borlist'>
                                        <thead>
                                        <?php print_r($_POST); ?>
                                        <tr align="center">
                                            <th>เลขที่ใบยืม</th>
                                            <th>วันที่เริ่มยืม</th>
                                            <th>กำหนดส่งคืน</th>
                                            <th>สถานะใบยืม</th>
                                            <th>การจัดการ</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        /*$(document).ready(function(){
            $("orderDetail").click(function(){
                $.post("Views/students/getOrderDetail.php",
                    {
                        name: "Donald Duck",
                        city: "Duckburg"
                    },
                    function(data,status){
                        alert("Data: " + data + "\nStatus: " + status);
                    });
            });
        });*//*
        $(document).ready(function(){
            $("c").click(function(){
                $.get("demo_test.asp", function(data, status){
                    alert("Data: " + data + "\nStatus: " + status);
                });
            });
        });*/
        /*function orderDetail(orderid) {
            //document.write(orderid);
            var orderid = orderid;
            $.ajax({
                document.write("55555555555555")
                type: "POST",
                url: "Views/students/getOrderDetail.php",
                data: {orderID: orderid},
                success: function (data) {
                    document.write("55555555555555")
                }
            });

        }*/

    </script>


