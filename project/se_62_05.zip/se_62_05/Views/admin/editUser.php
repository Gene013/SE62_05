<?php
session_start();
?>

<div class="container-fluid" align="center">
    <div>
        <br>
        <h2 align = 'center'>แก้ไขผู้ใช้</h2>
        <br>
    </div>
    <form method="post" action="index.php?controller=admin&action=addEditUser">
    <?php foreach ($UserList as $user) {if($user->id==$_POST['id']){ ?>
    <div class="container p-3 my-3 border" style="-webkit-box-flex: 0;
      -ms-flex: 0 0 calc(100% - 10px);
      flex: 0 0 calc(100% - 10px);
      max-width: calc(100% - 10px);
      width: calc(100% - 10px); } }">
        <input type="hidden" id="id" name="id" value="<?php echo $user->id; ?>">
            <div class="row">
                <div class="col-sm-6">
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text">บัญชีผู้ใช้</span>
                        </div>
                        <input type="text" class="number form-control" id="username" name="username" value='<?php echo $user->username; ?>'>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text">ชื่อ-นามสกุล</span>
                        </div>
                        <input type="text" class="form-control" id="name" name="name" value='<?php echo $user->name; ?>'>
                    </div>
                </div>
            </div>
            <div class="row" id="name">
                <div class="col-sm-6">
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text">E-mail</span>
                        </div>
                        <input type="text" class="form-control" id="mail" name="mail" value='<?php echo $user->mail;?>'>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <label class="input-group-text" for="serial">ประเภทผู้ใช้</label>
                        </div>
                        <select class="custom-select" id="role" name="role">
                            <?php if($user->role=="ADMIN"){
                                echo "<option value='ADMIN' selected>ADMIN</option>";
                                echo "<option value='TEACHER'>TEACHER</option>";
                            }elseif($user->role=="TEACHER"){
                                echo "<option value='TEACHER' selected>TEACHER</option>";
                                echo "<option value='ADMIN'>ADMIN</option>";
                            }?>

                        </select>
                    </div>
                </div>
            </div>
            <?php }} ?>
            <div align='center'>
                <button class="btn btn-primary" type="submit">ยืนยัน</button>&nbsp
                <a href="index.php?controller=admin&action=ManageUser" class="btn btn-danger">ยกเลิก</a>
            </div>
        </div>
    </form>
    </div>
</div>




