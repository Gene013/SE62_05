<?php
$controllers = array('pages'=>['form_login','error','home','detail'],
    'students'=>['borrow','checkStatus','borrowEquip'],
    'admin'=>['addEquipment','addEquip','edit_detail','editEquip','statistics','statistics_month',
                'statistics_year','ManageUser','set_date_cancel','editDate','editUser',
                'deleteEqu','addEditUser','addType','addT','formUser','addUser','removeUser',
                'ManageType','edittType','addEditType','removeType','ManageUserExternal','addUserE','removeUserE']);

function call($controller,$action){
    require_once ("Controllers/".$controller."_controller.php");
    switch ($controller){
        case "pages" :      require_once ('Models/equipmentModel.php');
                            require_once ('Models/typeModel.php');
                            $controller = new PagesController();
            break;
        case "students" :   require_once ('Models/typeModel.php');
                            require_once ('Models/equipmentModel.php');
                            require_once ('Models/orderModel.php');
                            require_once ('Models/teacherModel.php');
                            $controller = new StudentsController();
            break;
        case "admin" :      require_once ('Models/typeModel.php');
                            require_once ('Models/equipmentModel.php');
                            require_once ('Models/teacherModel.php');
                            require_once ('Models/userModel.php');
                            $controller = new AdminController();
            break;
    }
    $controller->{$action}();
}
if (array_key_exists($controller,$controllers)){
    if (in_array($action,$controllers[$controller])){
        call($controller,$action);
    }
    else{
        call('pages','error');
    }
}
else{
    call('pages','error');
}
?>
