<?php
    $user = "admin";
    $pass = "feng";
    $hash = password_hash($pass,PASSWORD_DEFAULT);

    echo $user;
    echo $pass."<br>";
    echo $hash;
?>