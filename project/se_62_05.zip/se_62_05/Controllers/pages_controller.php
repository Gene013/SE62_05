<?php
class PagesController{
    public function form_login(){
        require_once ('Views/pages/form_login.php');
    }
    public  function error(){
        require_once ('Views/pages/error.php');
    }
    public  function home(){
        $equipList = equipment::getAll();
        require_once ('Views/pages/home.php');
    }

    public  function detail(){
        $equipList = equipment::getAll();
        require_once ('Views/pages/detail.php');
    }
}
?>