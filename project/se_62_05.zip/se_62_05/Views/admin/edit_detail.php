<?php
$equ_id = $_POST['equ_id'];
$equ_name = $_POST['equ_name'];
$equ_type = $_POST['equ_type'];
$equ_pic = $_POST['equ_pic'];
$equ_serial = $_POST['equ_serial'];
$equ_status = $_POST['equ_status'];

?>

<div class="container-fluid" align="center">
    <div>
        <br><h2 align="center">แก้ไขรายละเอียดอุปกรณ์</h2><br>
    </div>
    <div class="container p-3 my-3 border" style="-webkit-box-flex: 0;
      -ms-flex: 0 0 calc(100% - 10px);
      flex: 0 0 calc(100% - 10px);
      max-width: calc(100% - 10px);
      width: calc(100% - 10px); } }">
        <div>
            <h4 align="center">ข้อมูลอุปกรณ์</h4>
        </div>
        <form id="editEquipment" runat="server" method="post" enctype="multipart/form-data" action="index.php?controller=admin&action=editEquip">
            <input type="hidden" id="id" name="id" value="<?php echo "$equ_id";?>">
            <div class="row">
                <div class="col-sm-6">
                    <div class="input-group mb-3" align="left">

                    </div><br>
                    <div>
                        <img id="blah" src="<?php echo "img/equipment/$equ_pic";?>" alt="" width="200">
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <label class="input-group-text" for="type">หมวดหมู่</label>
                        </div>
                        <select class="custom-select" id="type" name="type">
                            <?php foreach($typeList as $type){
                                if($type->typeName == $equ_type){
                                    echo "<option selected value= $type->id>$type->typeName</option>";}
                                else{
                                    echo "<option value= $type->id>$type->typeName</option>";
                                }
                            }?>

                        </select>
                    </div>
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text">ชื่ออุปกรณ์</span>
                        </div>
                        <input type="text" class="number form-control" id="name" name="name" value="<?php echo "$equ_name";?>">
                    </div>
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text">เลขครุภัณฑ์</span>
                        </div>
                        <input type="text" class="text form-control" id="serial" name="serial" value="<?php echo "$equ_serial";?>">
                    </div>
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <label class="input-group-text" for="type">สถานะการยืม</label>
                        </div>
                        <select class="custom-select" id="status" name="status">
                            <?php
                                if($equ_status==9){
                                    echo "<option selected value=\"9\">ยืมได้</option>
                                          <option value=\"10\">ยืมไม่ได้</option>";}
                                else{
                                    echo "<option value=\"9\">ยืมได้</option>
                                          <option selected value=\"10\">ยืมไม่ได้</option>";
                                }
                            ?>


                        </select>
                    </div>
                </div>
            </div>
            <div align='center'>
                <button class="btn btn-primary" type="submit">ยืนยัน</button>&nbsp
                <button class="btn btn-danger">ยกเลิก</button>
            </div>
        </form>
    </div>
</div>
<script type="text/javascript">
    $(function(){

        $("#inputFile").on("change",function(){
            var _files = $(this)[0].files;
            var _listFileName = "";
            if(_files.length>0){
                var _fileName = [];
                $.each(_files,function(k,v){
                    _fileName[k] = v.name;
                });
                _listFileName = _fileName.join(",");
            }
            $(this).next("label").text(_listFileName);
        });
    });
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#blah').attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]);
        }
    }
</script>