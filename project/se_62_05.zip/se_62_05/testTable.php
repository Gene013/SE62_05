<?php
//ตั้งค่าการเชื่อมต่อฐานข้อมูล
$database_host 			= 'localhost';
$database_username 		= 'se62_05';
$database_password 		= 'se62_05';
$database_name 			= 'se62_05';

$mysqli = new mysqli($database_host, $database_username, $database_password, $database_name);
//กำหนด charset ให้เป็น utf8 เพื่อรองรับภาษาไทย
$mysqli->set_charset("utf8");

//กรณีมี Error เกิดขึ้น
if ($mysqli->connect_error) {
    die('Error : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
}
$mount = date("m");
$year = date("Y");
$dateStart = date("Y-m-d");
$DayOfWeek = date("w", strtotime($dateStart));
for($i = 0;$DayOfWeek!=0;$i++ ){
    $dateStart = date("Y-m-d",strtotime($dateStart."-1 day"));
    $DayOfWeek = date("w", strtotime($dateStart));
}
$dateEnd = date("Y-m-d",strtotime($dateStart."+6 day"));;
$get_data = $mysqli->query("SELECT equipment.name_equ,COUNT(order_detail.equ_detail_id) AS Total,status_order.name FROM orders INNER JOIN order_detail ON orders.id=order_detail.order_id
INNER JOIN status_order ON orders.status_id=status_order.id 
INNER JOIN equiment_detail ON equiment_detail.id=order_detail.equ_detail_id
INNER JOIN equipment ON equipment.id=equiment_detail.equ_id
WHERE YEAR(orders.date_start)='$year' AND status_order.id=2
GROUP BY equipment.name_equ,status_order.name");


while($data = $get_data->fetch_assoc()){

    $result[] = $data;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>ตารางสรุปการยืมทั้งหมด</title>

    <!-- Bootstrap -->
    <!-- Latest compiled and minified CSS-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]-->
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <!--[endif]-->
</head>
<body>
<h3>ตารางสรุปการยืมทั้งหมด</h3>

<div class="col-sm-6" id="createGraph"></div>
<div class="col-sm-8">
<table class="table table-striped" id="datatable">
    <thead>
    <tr>
        <th></th>
        <th>จำนวนที่ถูกยืม</th>
    </tr>
    </thead>
    <tbody>
    <?php
    foreach($result as $result_tb){
        echo"<tr>";
        echo "<td>".$result_tb['name_equ']."</td>";
        echo "<td>".$result_tb['Total']."</td>";

        echo"</tr>";
    }
    ?>

    </tbody>
</table>
</div>


<script src="http://code.jquery.com/jquery-1.12.0.min.js"></script>
<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/data.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>

<script>

    $(function () {

        $('#createGraph').highcharts({
            data: {
                //กำหนดให้ ตรงกับ id ของ table ที่จะแสดงข้อมูล
                table: 'datatable'
            },
            chart: {
                type: 'column'
            },
            title: {
                text: 'สถิการยืมทั้งหมด'
            },
            yAxis: {
                allowDecimals: false,
                title: {
                    text: 'จำนวน'
                }
            },

            tooltip: {
                formatter: function () {
                    return '<b>' + this.series.name + '</b><br/>' +
                        this.point.y; + ' ' + this.point.name.toLowerCase();
                }
            }
        });
    });

</script>

</body>
</html>