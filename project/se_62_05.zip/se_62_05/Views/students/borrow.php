<?php
session_start();
unset($_SESSION['cart']);

if (isset($_SESSION["Logon"]) && $_SESSION["Logon"] == 1) {
    $ldap_uid = $_SESSION["ldap_uid"];
    $ldap_engname = $_SESSION["ldap_engname"];
    $ldap_thainame = $_SESSION["ldap_thainame"];
    $ldap_email = $_SESSION["ldap_email"];
    $ldap_gender = $_SESSION["ldap_gender"];
    $ldap_Job = $_SESSION["ldap_Job"];
    $ldap_position = $_SESSION["ldap_position"];
    $ldap_department = $_SESSION["ldap_department"];
    $ldap_faculty = $_SESSION["ldap_faculty"];
    $ldap_campus = $_SESSION["ldap_campus"];
    $ldap_Status = $_SESSION["ldap_Status"];
    $ldap_idcode = $_SESSION["ldap_idcode"];
    echo "<script>console.log('id $ldap_uid')</script>";
    echo "<script>console.log('thainame $ldap_thainame')</script>";
    echo "<script>console.log('engname $ldap_engname')</script>";
    echo "<script>console.log('status $ldap_Status')</script>";
} elseif (isset($_SESSION["Logon"]) && $_SESSION["Logon"] == 2) {
    $ldap_thainame = $_SESSION["ldap_thainame"];
    $ldap_Status = $_SESSION["ldap_Status"];
}else{
    header('location:form_login.php');
}
?>

<div class="container-fluid" align="center">
    <div>
        <br>
        <h2 align = 'center'>ยืมอุปกรณ์</h2>
        <br>
    </div>
    <div class="container p-3 my-3 border" style="-webkit-box-flex: 0;
      -ms-flex: 0 0 calc(100% - 10px);
      flex: 0 0 calc(100% - 10px);
      max-width: calc(100% - 10px);
      width: calc(100% - 10px); } }">
        <div>
            <h4 align="center">ข้อมูลผู้ยืม</h4>
        </div>
        <form method="post" action="index.php?controller=students&action=borrowEquip">
        <div class="row">
            <div class="col-sm-6">
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text">รหัสนิสิต</span>
                    </div>
                    <input type="text" class="number form-control" id="stdID" name="stdID" value='<?php echo substr($ldap_uid,1,10)?>' readonly>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text">วันที่ยืม</span>
                    </div>
                    <input type="date" class="form-control" id="dateStart" name="dateStart">
                </div>
            </div>
        </div>
        <div class="row" id="name">
            <div class="col-sm-6">
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text">ชื่อ-นามสกุล</span>
                    </div>
                    <input type="text" class="form-control" id="fname" name="fname" value='<?php echo $ldap_thainame?>' readonly>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text">วันที่คืน</span>
                    </div>
                    <input type='date' class='form-control' id='dateEnd' name='dateEnd'>
                </div>
            </div>
        </div>
        <div class="row" id="name">
            <div class="col-sm-6">
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text">รหัสสาขา</span>
                    </div>
                    <input type="text" class="form-control" id="fname" name="fname" value='<?php echo $ldap_department ?>' readonly>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text">E-mail</span>
                    </div>
                    <input type="text" class="form-control" id="fname" name="fname" value='<?php echo $ldap_email ?>' readonly>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6">
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <div class="input-group-text">
                            <input type="checkbox" aria-label="Checkbox for following text input" id="checkbox">
                        </div>
                    </div>
                    <input type="text" class="form-control" value="ใช้ในโครงการ" readonly>
                </div>
            </div>
        </div>
        <div class="row" id="project">
            <div class="col-sm-6">
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text">ชื่อโครงการ</span>
                    </div>
                    <input type="text" class="form-control" id="project_name" name="project_name">
                </div>
            </div>
            <div class="col-sm-6">
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <label class="input-group-text" for="type">อาจารย์ที่ปรึกษา</label>
                    </div>
                    <select class="custom-select" id="teacher" name="teacher">
                        <option value="0" selected>Choose...</option>
                        <?php foreach ($teacherList as $teacher){echo "<option value='$teacher->id'>$teacher->name</option>";}  ?>
                    </select>
                </div>
            </div>
        </div>
        <div class="row" id="reason">
            <div class="col-sm-12">
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text">เหตุผล</span>
                    </div>
                    <input type="text" class="form-control" id="reason" name="reason">
                </div>
            </div>
        </div>
        <div align='center'>
            <a style="color: white" class="btn btn-primary" data-toggle="modal" data-target="#ModelAdd">เพิ่มอุปกรณ์</a>
        </div><br>

        <!-- Modal -->
        <div class="modal fade" id="ModelAdd" tabindex="-1" role="dialog" aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-scrollable" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalScrollableTitle">เลือกอุปกรณ์</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="container p-3 my-3 border" style="-webkit-box-flex: 0;
      -ms-flex: 0 0 calc(100% - 10px);
      flex: 0 0 calc(100% - 10px);
      max-width: calc(100% - 10px);
      width: calc(100% - 10px); } }">
                            <div class="row">
                                <div class="input-group mb-12">
                                    <div class="input-group-prepend">
                                        <label class="input-group-text" for="type">หมวดหมู่</label>
                                    </div>
                                    <select class="custom-select" id="type" name="type">
                                        <option selected>Choose...</option>
                                    </select>
                                </div>
                            </div>
                            <br>
                            <div class="row">
                                <div class="input-group mb-12">
                                    <div class="input-group-prepend">
                                        <label class="input-group-text" for="equ">อุปกรณ์</label>
                                    </div>
                                    <select class="custom-select" id="equ" name="equ">
                                        <option selected>Choose...</option>
                                    </select>
                                </div>
                            </div>
                            <br>
                            <div class="row">
                                <div class="input-group mb-12">
                                    <div class="input-group-prepend">
                                        <label class="input-group-text" for="serial">เลขครุภัณฑ์</label>
                                    </div>
                                    <select class="custom-select" id="serial" name="serial">
                                        <option selected>Choose...</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">ปิด</button>
                        <button type="button" class="btn btn-primary" id="add" data-dismiss="modal" disabled="true">เพิ่มอุปกรณ์</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-9">
            <table class="table table-striped table-bordered" style="width:100%" id="borlist">
                <thead>
                <tr align="center">
                    <th>ชื่ออุปกรณ์</th><th>เลขครุภัณฑ์</th>
                </tr>
                </thead>
                <tbody id="list_detail"></tbody>
            </table>
        </div><br>
        <div align='center'>
            <button class="btn btn-primary" type="submit">ยืนยัน</button>&nbsp
            <a style="color: white" class="btn btn-warning" id="editlist">เลือกใหม่</a>&nbsp
            <a href="index.php?controller=pages&action=home" class="btn btn-danger">ยกเลิก</a>
        </div>
        </form>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function() {
        $('#borlist').DataTable();
    } );

    $(function(){
        $('#add').click(function(){
            var name = $('#equ').val();
            var serial = $('#serial').val();
            console.log(name);
            console.log(serial);
            addtocart(name,serial);
        });
    });

    $(function(){
        $('#editlist').click(function(){
            editList();
        });
    });

    function editList() {
        $.ajax({
            url : "Views/students/addToCart.php",
            data : {"action":"editCart"},
            dataType : "text",
            type : "POST",
            success : function(data){
                //alert(data);
                getCart();
            }
        });
    }

    function addtocart(name,serial){
        $.ajax({
            url : "Views/students/addToCart.php",
            data : {"action":"addToCart","name":name,"serial":serial},
            dataType : "text",
            type : "POST",
            success : function(data){
                //alert(data);
                getCart();
            }
        });
    }

    function getCart(){
        $.ajax({
            url : "Views/students/addToCart.php",
            data : { "action":"getCart"},
            dataType : "text",
            type: "POST",
            success: function(data){
                //alert(data);
                var info = data.split('*');
                console.log(info[0]);
                $('#list_detail').html(info[0]);
                if(typeof info[1] === "undefined"){

                }else{
                    $('#VTotalPrice').val(info[1]);
                }
            }
        });
    }

    $(document).ready(function getCart(){
        $.ajax({
            url : "Views/students/addToCart.php",
            data : { "action":"getCart"},
            dataType : "text",
            type: "POST",
            success: function(data){
                //alert(data);
                var info = data.split('*');
                console.log(info[0]);
                $('#list_detail').html(info[0]);
                if(typeof info[1] === "undefined"){

                }else{
                    $('#VTotalPrice').val(info[1]);
                }
            }
        });
    });

    $(document).ready(function() {
        $('#project').hide();
        $('#reason').hide();
        $('#checkbox').click(function(){
            const obj = document.querySelector("#checkbox");
            var $checkbox = obj.checked;
            console.log($checkbox);
            if ($checkbox==true) {
                $('#project').show();
                $('#reason').show();
            }else{
                $('#project').hide();
                $('#reason').hide();
            }
        });
    })

    $(document).ready(function () {
        $.getJSON("Views/students/getType.php",success=function (data) {
            var options="";
            for (var i=0;i<data.length;i++){
                options+="<option value='"+data[i]["id"]+"'>"+data[i]["type_name"]+"</option>";
            }
            console.log(options);
            $('#type').append(options);
            $('#type').change();
        });

        $('#type').change(function () {
            var options="";
            $.getJSON("Views/students/getEquipment.php?type_id="+$(this).val(),success=function (data) {
                for (var i=0;i<data.length;i++){
                    options+="<option value='"+data[i]["name_equ"]+"'>"+data[i]["name_equ"]+"</option>";
                }
                console.log(options);
                $('#equ').html("<option value='0' selected>Choose...</option>");
                $('#equ').append(options);
                $('#equ').change();
            });

            $('#equ').change(function () {
                var options="";
                $.getJSON("Views/students/getSerial.php?equ_id="+$(this).val(),success=function (data) {
                    for (var i=0;i<data.length;i++){
                        if (data[i]["status"]==9){
                            options+="<option value='"+data[i]["serial_number"]+"/"+data[i]["serial"]+"'>"+data[i]["serial_number"]+"/"+data[i]["serial"]+"</option>";
                        }
                    }
                    console.log(options);
                    $('#serial').html("<option value='0' selected>Choose...</option>");
                    $('#serial').append(options);
                    if($('#serial').val()!=0){
                        $('#serial').change();
                    }
                });

                $('#serial').change(function () {
                    btnenable();
                });

                function btnenable() {
                    document.getElementById("add").disabled = false;
                }
            });
        });
    });
</script>



