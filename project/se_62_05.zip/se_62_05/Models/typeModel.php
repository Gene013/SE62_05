<?php
class type{
    public $id;
    public $typeName;
    public  function __construct($id,$typeName){
        $this->id = $id;
        $this->typeName = $typeName;
    }
    public static function getAll(){
        $typeList=[];
        require('connect/db_connect.php');
        $sql = 'SELECT * FROM `type`';
        $result = mysqli_query($conn,$sql);

        while ($row = mysqli_fetch_assoc($result)){
            $id = $row['id'];
            $typeName = $row['type_name'];
            echo "<script>console.log('$id')</script>";
            $typeList[] = new type($id,$typeName);
        }
        require('connect/db_disconnect.php');
        return $typeList;
    }

    public static function addType($type_name){
        require('connect/db_connect.php');
        $sql = 'INSERT INTO `type` (`type_name`) VALUES ("'.$type_name.'")';
        if($result = mysqli_query($conn,$sql)){
            echo "<script>console.log('add success')</script>";
        }else{
            echo "<script>console.log('add fail')</script>";
        }
        require('connect/db_disconnect.php');
    }

    public static function editType($id,$type_name){
        require('connect/db_connect.php');
        $sql = 'UPDATE `type` SET `type_name`="'.$type_name.'" WHERE `id`="'.$id.'"';
        $result = mysqli_query($conn,$sql);
        if($result = mysqli_query($conn,$sql)){
            echo "<script>console.log('update success')</script>";
        }else{
            echo "<script>console.log('update fail')</script>";
        }
        require('connect/db_disconnect.php');
    }

    public static function removeType($id){
        require ('connect/db_connect.php');
        $sql = 'DELETE FROM `type` WHERE `id` = "'.$id.'"';
        if($result = mysqli_query($conn,$sql)){
            echo "<script>console.log('update success')</script>";
        }
        require('connect/db_disconnect.php');
    }
}
?>