<?php
session_start();

if (isset($_SESSION["Logon"]) && $_SESSION["Logon"] == 1) {
    $ldap_uid = $_SESSION["ldap_uid"];
    $ldap_engname = $_SESSION["ldap_engname"];
    $ldap_thainame = $_SESSION["ldap_thainame"];
    $ldap_email = $_SESSION["ldap_email"];
    $ldap_gender = $_SESSION["ldap_gender"];
    $ldap_Job = $_SESSION["ldap_Job"];
    $ldap_position = $_SESSION["ldap_position"];
    $ldap_department = $_SESSION["ldap_department"];
    $ldap_faculty = $_SESSION["ldap_faculty"];
    $ldap_campus = $_SESSION["ldap_campus"];
    $ldap_Status = $_SESSION["ldap_Status"];
    $ldap_idcode = $_SESSION["ldap_idcode"];
} elseif (isset($_SESSION["Logon"]) && $_SESSION["Logon"] == 2) {
    $ldap_thainame = $_SESSION["ldap_thainame"];
    $ldap_Status = $_SESSION["ldap_Status"];
}else{
    header('location:form_login.php');
}
?>
<div class="container-fluid" align="center">
    <div>
        <br>
        <h2 align = 'center'>รายละเอียดอุปกรณ์</h2>
        <br>
    </div>
    <div class="container p-3 my-3 border" style="-webkit-box-flex: 0;
      -ms-flex: 0 0 calc(100% - 10px);
      flex: 0 0 calc(100% - 10px);
      max-width: calc(100% - 10px);
      width: calc(100% - 10px); } }">
        <div class="row">
            <?php
            $equ_id = $_POST['equ_id'];
            $equ_name = $_POST['equ_name'];
            $equ_type = $_POST['equ_type'];
            $equ_pic = $_POST['equ_pic'];
            $equ_serial = $_POST['equ_serial'];
            $equ_status = $_POST['equ_status'];
            echo "
                        <div class='col-sm-6'>
                            <img src='img/equipment/$equ_pic' class='img-fluid' width='460' height='345'>
                            <script>console.log('$equ_pic')</script>
                        </div>
                        <div class='col-sm-3' align='right'>
                                <h6 class='text-dark'>ชื่ออุปกรณ์</h6>
                                <p class='text-dark'>หมวดหมู่</p>
                                <p class='text-dark'>เลขพัศดุ</p>
                                <p class='text-dark'>สถานะการยืม</p>
                        </div>
                            <div class='col-sm-3' align='left'>
                                <h6 class='card-title'>$equ_name</h6>
                                <p class='card-text'>$equ_type</p>
                                <p class='card-text'>$equ_serial</p>" ;
                                if($equ_status==10){
                                    echo "<a style='color: red'>ยืมไม่ได้</a><br><br>";
                                }
                                else{
                                    echo "<a style='color: green'>ยืมได้</a><br><br>";
                                }
            echo "
                                <form method='post' action='index.php?controller=admin&action=edit_detail' >
                                    <input type='hidden' name='equ_id' value='$equ_id'>
                                    <input type='hidden' name='equ_name' value='$equ_name'>
                                    <input type='hidden' name='equ_type' value='$equ_type'>
                                    <input type='hidden' name='equ_pic' value='$equ_pic'>
                                    <input type='hidden' name='equ_serial' value='$equ_serial'>
                                    <input type='hidden' name='equ_status' value='$equ_status'>
                                    <a href='index.php?controller=pages&action=home' class='btn btn-primary'>ย้อนกลับ</a>&nbsp;";

                if($ldap_Status=="ADMIN"){
                    echo "
                                
                                 <button class='btn btn-warning' type='submit'>แก้ไข</button>
                                   </form>";
                }

            echo "
                                <form method='post' action='index.php?controller=admin&action=deleteEqu' >
                                    <input type='hidden' name='id' value='$equ_id'>
                                                             <br>";

            if($ldap_Status=="ADMIN"){
                echo "
                                
                                 <button class='btn btn-danger' type='submit'>ลบ</button>
                                   </form>";
            }

                echo "
                            
                           </div> ";?>
        </div>
    </div>
</div>
