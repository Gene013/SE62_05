<?php

$teacher_id = $teacher;

    require("lib/phpmailer/PHPMailerAutoload.php");
    require('connect/db_connect.php');
    $sql = 'SELECT staff_teacher.email FROM staff_teacher WHERE staff_teacher.id="' . $teacher_id . '"';
    $result = mysqli_query($conn, $sql);
    while ($row = mysqli_fetch_assoc($result)) {
        $id = $row['id'];
        $name = $row['name'];
        $teacher_mail = $row['email'];
    }
    require('connect/db_disconnect.php');

    header('Content-Type: text/html; charset=utf-8');

    $mail = new PHPMailer;
    $mail->CharSet = "utf-8";
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->Port = 587;
    $mail->SMTPSecure = 'tls';
    $mail->SMTPAuth = true;


    $gmail_username = "thanathorn001@gmail.com"; // gmail ที่ใช้ส่ง
    $gmail_password = "Jason@013"; // รหัสผ่าน gmail
// ตั้งค่าอนุญาตการใช้งานได้ที่นี่ https://myaccount.google.com/lesssecureapps?pli=1


    $sender = "CPE"; // ชื่อผู้ส่ง
    $email_sender = "CPE@CPE.com"; // เมล์ผู้ส่ง
    $email_receiver = $teacher_mail; // เมล์ผู้รับ ***

    $subject = "แจ้งการอนุมัติ"; // หัวข้อเมล์


    $mail->Username = $gmail_username;
    $mail->Password = $gmail_password;
    $mail->setFrom($email_sender, $sender);
    $mail->addAddress($email_receiver);
    $mail->Subject = $subject;

    $email_content = "
	<!DOCTYPE html>
	<html>
		<head>
			<meta charset=utf-8'/>
			<title>ทดสอบการส่ง Email</title>
		</head>
		<body>
			<h1 style='background: #3b434c;padding: 10px 0 20px 10px;margin-bottom:10px;font-size:30px;color:white;' >
				<img src='https://s3-ap-southeast-1.amazonaws.com/img-in-th/8ab9c8b32cd0c48ec52ff4dded84f06f.jpg' style='width: 80px;'>
				CPE ใจดีให้ยืม
			</h1>
			<div style='padding:20px;'>
				<div>				
					<h2>กรุณาเข้าไปตรวจสอบการยืมของนิสิต : <strong style='color:#0000ff;'></strong></h2>
					<a href='http://158.108.207.4/se62_05/form_login.php' target='_blank'>
						<h1><strong style='color:#3c83f9;'> >> กรุณาคลิ๊กที่นี่ << </strong> </h1>
					</a>
				</div>
				<div style='margin-top:30px;'>
					<hr>
					<address>
						<h4>ติดต่อสอบถาม</h4>
						
						<p>CPE ใจดีให้ยืม</p>
						<a href='http://158.108.207.4/se62_05/form_login.php' target='_blank'>
						<p>www.CPE ใจดีให้ยืม.com</p></a>
					</address>
				</div>
			</div>
			<div style='background: #3b434c;color: #a2abb7;padding:30px;'>
				<div style='text-align:center'> 
					 CPE ใจดีให้ยืม
				</div>
			</div>
		</body>
	</html>
";

//  ถ้ามี email ผู้รับ
    if ($email_receiver) {
        $mail->msgHTML($email_content);


        if (!$mail->send()) {  // สั่งให้ส่ง email

            // กรณีส่ง email ไม่สำเร็จ
            echo "<script>console.log('fail to send mail')</script>";
            //echo $mail->ErrorInfo; // ข้อความ รายละเอียดการ error
        } else {
            // กรณีส่ง email สำเร็จ
            echo "<script>console.log('send mail success')</script>";
        }




}
?>