<?php
class teacher{
    public $id;
    public $username;
    public $name;
    public $mail;
    public $role;
    public  function __construct($id,$username,$name,$mail,$role){
        $this->id = $id;
        $this->username = $username;
        $this->name = $name;
        $this->mail = $mail;
        $this->role = $role;
    }
    public static function getAll(){
        $teacherList=[];
        require('connect/db_connect.php');
        $sql = 'SELECT * FROM staff_teacher WHERE staff_teacher.role="TEACHER"';
        $result = mysqli_query($conn,$sql);
        while ($row = mysqli_fetch_assoc($result)){
            $id = $row['id'];
            $username = $row['username'];
            $name = $row['name'];
            $mail = $row['email'];
            $role = $row['role'];
            echo "<script>console.log('$id')</script>";
            echo "<script>console.log('$name')</script>";
            $teacherList[] = new teacher($id,$username,$name,$mail,$role);
        }
        require('connect/db_disconnect.php');
        return $teacherList;
    }
    public static function getUserAll(){
        $teacherList=[];
        require('connect/db_connect.php');
        $sql = 'SELECT * FROM staff_teacher';
        $result = mysqli_query($conn,$sql);
        while ($row = mysqli_fetch_assoc($result)){
            $id = $row['id'];
            $username = $row['username'];
            $name = $row['name'];
            $mail = $row['email'];
            $role = $row['role'];
            $teacherList[] = new teacher($id,$username,$name,$mail,$role);
        }
        require('connect/db_disconnect.php');
        return $teacherList;
    }
    public static function addEditUser($id,$username,$name,$mail,$role){
        require ('connect/db_connect.php');
        $sql = 'UPDATE `staff_teacher` SET `username`="'.$username.'",`role`="'.$role.'",`name`="'.$name.'",`email`="'.$mail.'" WHERE `id`="'.$id.'" ';
        if($result = mysqli_query($conn,$sql)){
            echo "<script>console.log('update success')</script>";
        }
        require('connect/db_disconnect.php');
    }
    public static function addUser($username,$name,$mail,$role){
        require ('connect/db_connect.php');
        $sql = 'INSERT INTO `staff_teacher` (`username`, `role`, `name`, `email`) VALUES ( "'.$username.'","'.$role.'", "'.$name.'", "'.$mail.'")';
        if($result = mysqli_query($conn,$sql)){
            echo "<script>console.log('update success')</script>";
        }
        require('connect/db_disconnect.php');
    }
    public static function removeUser($id){
        require ('connect/db_connect.php');
        $sql = 'DELETE FROM `staff_teacher` WHERE `id` = "'.$id.'"';
        if($result = mysqli_query($conn,$sql)){
            echo "<script>console.log('update success')</script>";
        }
        require('connect/db_disconnect.php');
    }
}
?>