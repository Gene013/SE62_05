<?php
    session_start();
    unset($_SESSION['cart']);
?>
<div class="container-fluid" align="center">
    <div>
        <br><h2 align="center">เพิ่มอุปกรณ์</h2><br>
    </div>
    <div class="container p-3 my-3 border" style="-webkit-box-flex: 0;
      -ms-flex: 0 0 calc(100% - 10px);
      flex: 0 0 calc(100% - 10px);
      max-width: calc(100% - 10px);
      width: calc(100% - 10px); } }">
        <div>
            <h4 align="center">ข้อมูลอุปกรณ์</h4>
        </div>
        <form id="addEquipment" runat="server" method="post" enctype="multipart/form-data" action="index.php?controller=admin&action=addEquip">
            <div class="row">
                <div class="col-sm-6">
                        <div class="input-group mb-3" align="left">
                            <div class="input-group-prepend">
                                <span class="input-group-text">รูปภาพ</span>
                            </div>
                            <div class="custom-file">
                                <input type="file" class="custom-file-input" id="inputFile" name="inputFile" onchange="readURL(this);"/>
                                <label class="custom-file-label" for="inputFile" id="file">Choose file</label>
                                <input type="hidden" id="test" name="test" value="aaaaaaaa">
                            </div>
                        </div><br>
                        <div>
                            <img id="blah" src="#" alt="" width="200">
                        </div>
                </div>
                <div class="col-sm-6">
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <label class="input-group-text" for="type">หมวดหมู่</label>
                        </div>
                        <select class="custom-select" id="type" name="type">
                            <option selected>Choose...</option>
                            <?php foreach($typeList as $type){echo "<option value= $type->id>$type->typeName</option>"; }?>
                        </select>
                    </div>
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text">ชื่ออุปกรณ์</span>
                        </div>
                        <input type="text" class="number form-control" id="name" name="name">
                    </div>
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <span class="input-group-text">เลขครุภัณฑ์</span>
                        </div>
                        <input type="text" class="number form-control" id="serial" name="serial">
                    </div>
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <label class="input-group-text" for="type">สถานะการยืม</label>
                        </div>
                        <select class="custom-select" id="status" name="status">
                            <option selected>Choose...</option>
                            <option value="9">ยืมไม่ได้</option>
                            <option value="10">ยืมได้</option>
                        </select>
                    </div>
                </div>
            </div>
            <div align='center'>
                <a class="btn btn-primary" style="color: white" data-toggle="modal" data-target="#ModelAdd">เพิ่มเลขครุภัณฑ์ย่อย</a>
            </div><br>

            <!-- Modal -->
            <div class="modal fade" id="ModelAdd" tabindex="-1" role="dialog" aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
                <div class="modal-dialog modal-dialog-scrollable" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalScrollableTitle">เพิ่มเลขครุภัณฑ์ย่อย</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="container p-3 my-3 border" style="-webkit-box-flex: 0;
      -ms-flex: 0 0 calc(100% - 10px);
      flex: 0 0 calc(100% - 10px);
      max-width: calc(100% - 10px);
      width: calc(100% - 10px); } }">
                                <div class="row">
                                    <div class="input-group mb-12">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">เลขครุภัณฑ์ย่อย</span>
                                        </div>
                                        <input type="text" class="number form-control" id="s_serial" name="s_serial">
                                    </div>
                                </div>
                                <br>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">ปิด</button>
                            <button type="button" class="btn btn-primary" id="add" data-dismiss="modal">เพิ่มอุปกรณ์</button>
                        </div>
                    </div>
                </div>
            </div>
            <!--endModel-->
            <div class="col-md-9">
                <table class="table table-striped table-bordered" style="width:100%" id="borlist">
                    <thead>
                    <tr align="center">
                        <th>เลขครุภัณฑ์(หลัก)</th><th>เลขครุภัณฑ์(ย่อย)</th>
                    </tr>
                    </thead>
                    <tbody id="list_detail"></tbody>
                </table>
            </div><br>
            <div align='center'>
                <button class="btn btn-primary" type="submit">ยืนยัน</button>&nbsp
                <a style="color: white" class="btn btn-warning" id="editlist">เลือกใหม่</a>&nbsp
                <a href="index.php?controller=pages&action=home" class="btn btn-danger">ยกเลิก</a>
            </div>
        </form>
    </div>
</div>
<script type="text/javascript">
    $(function(){

        $("#inputFile").on("change",function(){
            var _files = $(this)[0].files;
            var _listFileName = "";
            if(_files.length>0){
                var _fileName = [];
                $.each(_files,function(k,v){
                    _fileName[k] = v.name;
                });
                _listFileName = _fileName.join(",");
            }
            $(this).next("label").text(_listFileName);
        });
    });
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#blah').attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]);
        }
    }

    $(document).ready(function () {
        $(function(){
            $('#add').click(function(){
                var serial = $('#serial').val();
                var s_serial = $('#s_serial').val();
                console.log(serial);
                console.log(s_serial);
                addtocart(serial,s_serial);
            });
        });

        function addtocart(serial,s_serial){
            $.ajax({
                url : "Views/admin/addToCart.php",
                data : {"action":"addToCart","serial":serial,"s_serial":s_serial},
                dataType : "text",
                type : "POST",
                success : function(data){
                    //alert(data);
                    getCart();
                }
            });
        }

        function getCart(){
            $.ajax({
                url : "Views/admin/addToCart.php",
                data : { "action":"getCart"},
                dataType : "text",
                type: "POST",
                success: function(data){
                    //alert(data);
                    var info = data.split('*');
                    console.log(info[0]);
                    $('#list_detail').html(info[0]);
                    if(typeof info[1] === "undefined"){

                    }else{
                        $('#VTotalPrice').val(info[1]);
                    }
                }
            });
        }

        $(function(){
            $('#editlist').click(function(){
                editList();
            });
        });

        function editList() {
            $.ajax({
                url : "Views/admin/addToCart.php",
                data : {"action":"editCart"},
                dataType : "text",
                type : "POST",
                success : function(data){
                    //alert(data);
                    getCart();
                }
            });
        }
    })

    $(document).ready(function getCart(){
        $.ajax({
            url : "Views/admin/addToCart.php",
            data : { "action":"getCart"},
            dataType : "text",
            type: "POST",
            success: function(data){
                //alert(data);
                var info = data.split('*');
                console.log(info[0]);
                $('#list_detail').html(info[0]);
                if(typeof info[1] === "undefined"){

                }else{
                    $('#VTotalPrice').val(info[1]);
                }
            }
        });
    });
</script>