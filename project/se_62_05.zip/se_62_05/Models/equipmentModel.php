<?php
class equipment{
    public $id;
    public $name;
    public $type;
    public $serial;
    public $pic;
    public $status;


    public  function __construct($id,$name,$type,$serial,$pic,$status){
        $this->id = $id;
        $this->name = $name;
        $this->type = $type;
        $this->serial = $serial;
        $this->pic = $pic;
        $this->status = $status;
    }
    public  static function addEquipment($name,$type,$serial,$pic,$status,$cart){
        echo "<script>console.log('$type')</script>";
        require('connect/db_connect.php');
        echo "<script>console.log('$name')</script>";
        $sql = 'SELECT AUTO_INCREMENT FROM information_schema.TABLES WHERE TABLE_SCHEMA = "se62_05" AND TABLE_NAME = "equipment"';
        if($result = mysqli_query($conn,$sql)){
            $row = mysqli_fetch_assoc($result);
            $id = $row['AUTO_INCREMENT'];
            $file = explode('.',$pic['name']);
            $filename = $id.'.'.$file[1];
            $dir = 'img/equipment/';
            echo "<script>console.log('$filename')</script>";
            if(file_exists($dir.$filename)) {
                echo $filename . " already exists. ";
            }else{
                $sql = 'INSERT INTO equipment (name_equ,type_equ,serial_number,pic,status) VALUES ("'.$name.'","'.$type.'","'.$serial.'","'.$filename.'","'.$status.'")';
                echo "<script>console.log('$dir$filename')</script>";
                if($result = mysqli_query($conn,$sql)){
                    echo "<script>console.log('upload success')</script>";
                    for ($i=0;$i<count($cart);$i++){
                        $sql = 'INSERT INTO `equiment_detail` ( `equ_id`, `serial`, `status`) VALUES ( "'.$id.'", "'.$cart[$i][1].'", "'.$status.'")';
                        if($result = mysqli_query($conn,$sql)){
                            echo "<script>console.log('upload success1')</script>";
                        }else{
                            echo "<script>console.log('upload error1')</script>";
                        }
                    };
                }else{
                    echo "<script>console.log('upload error')</script>";
                }
            }
        }else{
            echo "Upload Error";
        }
        require('connect/db_disconnect.php');
        return $dir.$filename;
    }
    public static function getAll(){
        $equipList=[];
        require('connect/db_connect.php');
        $sql = 'SELECT equipment.id,equipment.name_equ,type.type_name,equipment.serial_number,equipment.pic,equipment.status FROM equipment INNER JOIN type ON equipment.type_equ=type.id';
        if($result = mysqli_query($conn,$sql)){
            while ($row = mysqli_fetch_assoc($result))
            {
                $id = $row['id'];
                $name = $row['name_equ'];
                $type = $row['type_name'];
                $serial = $row['serial_number'];
                $pic = $row['pic'];
                $status = $row['status'];
                $equipList[] = new equipment($id,$name,$type,$serial,$pic,$status);
            }
        }
        require('connect/db_disconnect.php');
        return$equipList;

    }

    public  static function editEquipment($id,$name,$type,$serial,$status){
        //$oldStatus = 0;
        if($status==9) $oldStatus = 10;
        else if($status==10) $oldStatus = 9;
       require('connect/db_connect.php');
        $sql = 'UPDATE equipment SET name_equ="'.$name.'",type_equ="'.$type.'",serial_number="'.$serial.'",status="'.$status.'" WHERE equipment.id="'.$id.'"';
        if($result = mysqli_query($conn,$sql)){
            echo "<script>console.log('update success')</script>";
        }else{
            echo "<script>console.log('update fail')</script>";
        }
        require('connect/db_connect.php');
        $sql = 'UPDATE equiment_detail SET equiment_detail.status="'.$status.'" WHERE equiment_detail.equ_id="'.$id.'" AND equiment_detail.status="'.$oldStatus.'"';
        if($result = mysqli_query($conn,$sql)){
            echo "<script>console.log('update success1')</script>";
        }else{
            echo "<script>console.log('update fail1')</script>";
        }
        require('connect/db_disconnect.php');

    }

    public  static function deleteEquipment($id){
        require('connect/db_connect.php');
        $sql = 'DELETE FROM equipment WHERE equipment.id="'.$id.'"';
        if($result = mysqli_query($conn,$sql)){
            echo "<script>console.log('delete success')</script>";
        }else{
            echo "<script>console.log('delete fail')</script>";
        }
        require('connect/db_connect.php');
        $sql = 'DELETE FROM equiment_detail WHERE equiment_detail.equ_id="'.$id.'"';
        if($result = mysqli_query($conn,$sql)){
            echo "<script>console.log('delete success1')</script>";
        }else{
            echo "<script>console.log('delete fail1')</script>";
        }
        require('connect/db_disconnect.php');

    }
}
?>