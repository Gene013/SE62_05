<?php
    if (!isset($_SESSION["logon"])){
        session_start();
    }
    require_once 'connect/db_connect.php';
    ?>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    </head>
    <body>
    <?php
        if(isset($_SESSION["logon"])&&$_SESSION["logon"]==1){
            //nothing
        }
        else{
            include 'ldap.php';
            if(isset($_POST["form_account"])&&!empty($_POST["form_account"])){
                $your_account = str_replace("*","",strtolower(trim($_POST['form_account'])));
            }
            if (isset($_POST["form_password"]) && !empty($_POST["form_password"])) {
                $your_password = $_POST["form_password"];
            }
            $ldap_authen_result = user_authen($your_account, $your_password);
            if ($ldap_authen_result > 0) {
                $sql = "SELECT * FROM user";
                $result = mysqli_query($conn,$sql);
                if(mysqli_num_rows($result) > 0){
                    $user = $_POST["form_account"];
                    $pass = $_POST["form_password"];
                    $sql = "SELECT * FROM user WHERE UPPER(user) = UPPER('".$user."') LIMIT 1";
                    $result = mysqli_query($conn,$sql);
                    if(mysqli_num_rows($result) > 0){
                        $row = mysqli_fetch_assoc($result);
                        if(password_verify($pass,$row['pass'])){
                            unset($row['pass']);
                            $_SESSION['user_info'] = $row;
                            $_SESSION['ldap_Status'] = $row['role'];
                            $_SESSION["ldap_thainame"] = $row['user'];
                            $_SESSION["Logon"] = 2;
                            header('Location:index.php?controller=pages&action=home');
                        }else{
                            echo "<center><font color=RED>" . $ldap_error[$ldap_authen_result] . "</font></center><br>";
                        }
                    }else{
                        echo "<center><font color=RED>" . $ldap_error[$ldap_authen_result] . "</font></center><br>";
                    }
                }else{
                    echo "<center><font color=RED>" . $ldap_error[$ldap_authen_result] . "</font></center><br>";
                }
            } else {
                $_SESSION["Logon"] = 1;
            }
        }
        if (isset($_SESSION["Logon"]) && $_SESSION["Logon"]==1){
            if (!isset($_SESSION["ldap_uid"])){
                $_SESSION["ldap_uid"]		= $ldap_uid;
                $_SESSION["ldap_engname"]	= $ldap_engname;
                $_SESSION["ldap_thainame"]	= $ldap_thainame;
                $_SESSION["ldap_email"]		= $ldap_email;
                $_SESSION["ldap_gender"]	= $ldap_gender;
                $_SESSION["ldap_Job"]		= $ldap_Job;
                $_SESSION["ldap_position"]	= $ldap_position;
                $_SESSION["ldap_department"]= $ldap_department;
                $_SESSION["ldap_faculty"]	= $ldap_faculty;
                $_SESSION["ldap_campus"]	= $ldap_campus;
                $_SESSION["ldap_Status"]    = $ldap_Status;
                $_SESSION["ldap_idcode"]    = $ldap_idcode;
                $_SESSION["test"]           = $test;
            }
            if($ldap_Status=="Student"){
                if ($ldap_department=="E29"){
                    header('Location:index.php?controller=pages&action=home');
                }
            }else{
                $sql = "SELECT * FROM `staff_teacher` WHERE staff_teacher.username='".$_POST["form_account"]."'";
                $result = mysqli_query($conn,$sql);
                if(mysqli_num_rows($result) > 0){
                    $_SESSION['ldap_Status'] = $row['role'];
                    header('Location:index.php?controller=pages&action=home');
                }
            }
        }
    ?>
    </body>
</html>
