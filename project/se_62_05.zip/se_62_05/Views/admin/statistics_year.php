<?php
session_start();

if (isset($_SESSION["Logon"]) && $_SESSION["Logon"] == 1) {
    $ldap_uid = $_SESSION["ldap_uid"];
    $ldap_engname = $_SESSION["ldap_engname"];
    $ldap_thainame = $_SESSION["ldap_thainame"];
    $ldap_email = $_SESSION["ldap_email"];
    $ldap_gender = $_SESSION["ldap_gender"];
    $ldap_Job = $_SESSION["ldap_Job"];
    $ldap_position = $_SESSION["ldap_position"];
    $ldap_department = $_SESSION["ldap_department"];
    $ldap_faculty = $_SESSION["ldap_faculty"];
    $ldap_campus = $_SESSION["ldap_campus"];
    $ldap_Status = $_SESSION["ldap_Status"];
    $ldap_idcode = $_SESSION["ldap_idcode"];
} elseif (isset($_SESSION["Logon"]) && $_SESSION["Logon"] == 2) {
    $ldap_thainame = $_SESSION["ldap_thainame"];
    $ldap_Status = $_SESSION["ldap_Status"];
}else{
    header('location:form_login.php');
}

//ตั้งค่าการเชื่อมต่อฐานข้อมูล
$database_host 			= 'localhost';
$database_username 		= 'se62_05';
$database_password 		= 'se62_05';
$database_name 			= 'se62_05';

$mysqli = new mysqli($database_host, $database_username, $database_password, $database_name);
//กำหนด charset ให้เป็น utf8 เพื่อรองรับภาษาไทย
$mysqli->set_charset("utf8");

//กรณีมี Error เกิดขึ้น
if ($mysqli->connect_error) {
    die('Error : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
}
$mount = date("m");
$year = date("Y");
$dateStart = date("Y-m-d");
$DayOfWeek = date("w", strtotime($dateStart));
for($i = 0;$DayOfWeek!=0;$i++ ){
    $dateStart = date("Y-m-d",strtotime($dateStart."-1 day"));
    $DayOfWeek = date("w", strtotime($dateStart));
}
$dateEnd = date("Y-m-d",strtotime($dateStart."+6 day"));;

$get_dataMounth = $mysqli->query("SELECT COUNT(order_detail.equ_detail_id) AS y,equipment.name_equ AS label FROM orders INNER JOIN order_detail ON orders.id=order_detail.order_id
INNER JOIN status_order ON orders.status_id=status_order.id 
INNER JOIN equiment_detail ON equiment_detail.id=order_detail.equ_detail_id
INNER JOIN equipment ON equipment.id=equiment_detail.equ_id
WHERE YEAR(orders.date_start)='$year' AND MONTH(orders.date_start)='$mount' AND status_order.id=2
GROUP BY equipment.name_equ,status_order.name");

$get_dataWeek = $mysqli->query("SELECT COUNT(order_detail.equ_detail_id) AS y,equipment.name_equ AS label FROM orders INNER JOIN order_detail ON orders.id=order_detail.order_id
INNER JOIN status_order ON orders.status_id=status_order.id 
INNER JOIN equiment_detail ON equiment_detail.id=order_detail.equ_detail_id
INNER JOIN equipment ON equipment.id=equiment_detail.equ_id
WHERE orders.date_start>='$dateStart' AND orders.date_end<='$dateEnd' AND status_order.id=2
GROUP BY equipment.name_equ,status_order.name");

$get_dataYear = $mysqli->query("SELECT COUNT(order_detail.equ_detail_id) AS y,equipment.name_equ AS label FROM orders INNER JOIN order_detail ON orders.id=order_detail.order_id
INNER JOIN status_order ON orders.status_id=status_order.id 
INNER JOIN equiment_detail ON equiment_detail.id=order_detail.equ_detail_id
INNER JOIN equipment ON equipment.id=equiment_detail.equ_id
WHERE YEAR(orders.date_start)='$year' AND status_order.id=2
GROUP BY equipment.name_equ,status_order.name");


//COUNT(order_detail.equ_detail_id) AS y,equipment.name_equ AS label

while($data = $get_dataYear->fetch_assoc()){

    $resultyear[] = $data;

}
while($data = $get_dataMounth->fetch_assoc()){

    $resultmounth[] = $data;

}
while($data = $get_dataWeek->fetch_assoc()){

    $resultweek[] = $data;

}

?>
<center><a href='index.php?controller=admin&action=statistics' class='btn btn-primary'>รายสัปดาห์</a>&nbsp;
    <a href='index.php?controller=admin&action=statistics_month' class='btn btn-primary'>รายเดือน</a>&nbsp;
    <a href='index.php?controller=admin&action=statistics_year' class='btn btn-primary'>รายปี</a>&nbsp;</center><br>


<?php
$dataPoints = $resultyear;
?>
<script>
    window.onload = function() {

        var chart3 = new CanvasJS.Chart("chartContainer", {
            animationEnabled: true,
            theme: "light2",
            title:{
                text: "สถิติการยืมรายปี"
            },
            axisY: {
                title: "จำนวน"
            },
            data: [{
                type: "column",
                yValueFormatString: "#### ครั้ง",
                dataPoints: <?php echo json_encode($dataPoints, JSON_NUMERIC_CHECK); ?>
            }]
        });
        chart3.render();

    }
</script>
<div id="chartContainer" style="height: 470px; width: 100%;"></div>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>

</div>