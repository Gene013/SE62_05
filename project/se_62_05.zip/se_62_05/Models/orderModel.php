<?php

class order
{
    public $id;
    public $name;
    public $student_id;
    public $mail;
    public $date_start;
    public $date_end;
    public $reason;
    public $project_name;
    public $teacher_id;
    public $teacher_reason;
    public $status_id;
    public $status_name;
    public $serial_number;
    public $serial;

    /*
     public function __construct($id, $date_start, $date_end, $status_name)
     {
         $this->id = $id;
         $this->date_start = $date_start;
         $this->date_end = $date_end;
         $this->status_name = $status_name;
     }*/

    public function __construct($id = "", $name = "", $student_id = "", $mail = "", $date_start = "", $date_end = "", $reason = "", $project_name = "", $teacher_id = "", $teacher_reason = "", $status_id = "", $status_name = "", $serial_number = "", $serial = "")
    {
        $this->id = $id;
        $this->name = $name;
        $this->student_id = $student_id;
        $this->mail = $mail;
        $this->date_start = $date_start;
        $this->date_end = $date_end;
        $this->reason = $reason;
        $this->project_name = $project_name;
        $this->teacher_id = $teacher_id;
        $this->teacher_reason = $teacher_reason;
        $this->status_id = $status_id;
        $this->status_name = $status_name;
        $this->serial_number = $serial_number;
        $this->serial = $serial;
    }


    public static function getStatus($student_id)
    {
        require('connect/db_connect.php');
        $sql = 'SELECT orders.id,orders.date_start,orders.date_end,status_order.name FROM orders INNER JOIN status_order ON status_order.id = orders.status_id WHERE (orders.student_id=' . $student_id . ') &&( orders.status_id = 1||orders.status_id = 2 || orders.status_id=3|| orders.status_id=4|| orders.status_id=5|| orders.status_id=6|| orders.status_id=7|| orders.status_id=8)';
        if ($result = mysqli_query($conn, $sql)) {
            while ($row = mysqli_fetch_assoc($result)) {
                $id = $row['id'];
                $date_start = $row['date_start'];
                $date_end = $row['date_end'];
                $status_name = $row['name'];
                $orderStatus[] = new order($id, "","","",$date_start,$date_end,"","","","","",$status_name,"","");
            }
        }
        require('connect/db_disconnect.php');
        return $orderStatus;
    }

    public function addOrder($name, $std_id, $mail, $dateStart, $dateEnd, $reason, $project_name, $teacher_id, $cart)
    {
        require('connect/db_connect.php');
        $sql1 = 'SELECT AUTO_INCREMENT FROM information_schema.TABLES WHERE TABLE_SCHEMA = "se62_05" AND TABLE_NAME = "orders"';
        if ($result = mysqli_query($conn, $sql1)) {
            $row = mysqli_fetch_assoc($result);
            $id = $row['AUTO_INCREMENT'];
        }
        $sql2 = 'INSERT INTO `orders` ( `name`, `student_id`, `mail`, `date_start`, `date_end`, `reason`, `project_name`, `teacher_id`, `teacher_reason`, `status_id`) VALUES ( "' . $name . '", "' . $std_id . '","' . $mail . '", "' . $dateStart . '", "' . $dateEnd . '", "' . $reason . '", "' . $project_name . '", "' . $teacher_id . '", " ", "1")';
        if ($result = mysqli_query($conn, $sql2)) {
            echo "<script>console.log('upload success')</script>";
        } else {
            echo "<script>console.log('upload error')</script>";
        }
        for ($i = 0; $i < count($cart); $i++) {
            $sql = 'SELECT equipment.id FROM `equipment` WHERE equipment.name_equ ="' . $cart[$i][0] . '"';
            if ($result = mysqli_query($conn, $sql)) {
                $row = mysqli_fetch_assoc($result);
                $equ_id = $row['id'];
                echo "<script>console.log('equ_id')</script>";
                echo "<script>console.log('$equ_id')</script>";
                $sql = 'SELECT equiment_detail.id FROM equiment_detail WHERE equiment_detail.equ_id="' . $equ_id . '"';
                if ($result = mysqli_query($conn, $sql)) {
                    $row = mysqli_fetch_assoc($result);
                    $detal_id = $row['id'];
                    echo "<script>console.log('detal_id')</script>";
                    echo "<script>console.log('$detal_id')</script>";
                    $sql = 'INSERT INTO `order_detail` ( `order_id`, `equ_detail_id`) VALUES ( "' . $id . '", "' . $detal_id . '")';
                    if ($result = mysqli_query($conn, $sql)) {
                        echo "<script>console.log('upload success')</script>";
                    } else {
                        echo "<script>console.log('upload error')</script>";
                    }
                }
            }
            //$sql = 'INSERT INTO `order_detail` (`id`, `order_id`, `equ_detail_id`) VALUES (NULL, "'.$cart[$i][0].'", \'\')';
        };

    }

    public static function getOrderDetail($orderid)
    {

        require('connect/db_connect.php');
        $sql = 'SELECT orders.id,equipment.name_equ,equipment.serial_number,equiment_detail.serial FROM orders INNER JOIN order_detail ON order_detail.order_id=orders.id INNER JOIN equiment_detail ON equiment_detail.id = order_detail.equ_detail_id INNER JOIN equipment ON equipment.id=equiment_detail.equ_id WHERE orders.id=' . $orderid;
        if ($result = mysqli_query($conn, $sql)) {
            while ($row = mysqli_fetch_assoc($result)) {
                $id = $row['id'];
                $name = $row['name_equ'];
                $serial_number = $row['serial_number'];
                $serial = $row['serial'];
                $orderDetail[] = new order($id, $name, "", "", "", "", "", "", "", "", "", "", $serial_number,$serial);
            }
        }
        require('connect/db_disconnect.php');
        return $orderDetail;
    }
}
