-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 26, 2020 at 11:08 AM
-- Server version: 5.7.29-0ubuntu0.16.04.1
-- PHP Version: 7.2.28-3+ubuntu16.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `se62_05`
--

-- --------------------------------------------------------

--
-- Table structure for table `date_cancel`
--

CREATE TABLE `date_cancel` (
  `id` int(11) NOT NULL,
  `num_date` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `date_cancel`
--

INSERT INTO `date_cancel` (`id`, `num_date`) VALUES
(1, 6);

-- --------------------------------------------------------

--
-- Table structure for table `equiment_detail`
--

CREATE TABLE `equiment_detail` (
  `id` int(11) NOT NULL,
  `equ_id` int(11) NOT NULL,
  `serial` varchar(10) CHARACTER SET utf8 NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `equiment_detail`
--

INSERT INTO `equiment_detail` (`id`, `equ_id`, `serial`, `status`) VALUES
(1, 1, '001', 9),
(2, 1, '002', 9),
(3, 2, '001', 9),
(4, 2, '002', 9),
(5, 4, '001', 9),
(6, 4, '002', 9),
(7, 6, '001', 10),
(8, 6, '002', 10),
(9, 9, '001', 10),
(10, 9, '002', 10),
(11, 10, '001', 10),
(12, 10, '002', 10),
(13, 11, '001', 9),
(14, 11, '002', 9),
(15, 12, '001', 9),
(16, 12, '002', 9),
(17, 13, '001', 9),
(18, 13, '002', 9),
(19, 14, '001', 9),
(20, 14, '002', 9),
(21, 15, '001', 10),
(22, 17, '001', 10),
(23, 17, '002', 10),
(24, 17, '003', 10),
(30, 20, '001', 9),
(31, 20, '002', 9);

-- --------------------------------------------------------

--
-- Table structure for table `equipment`
--

CREATE TABLE `equipment` (
  `id` int(11) NOT NULL,
  `name_equ` varchar(100) CHARACTER SET utf8 NOT NULL,
  `type_equ` int(11) NOT NULL,
  `serial_number` varchar(20) CHARACTER SET utf8 NOT NULL,
  `pic` varchar(20) CHARACTER SET utf8 NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `equipment`
--

INSERT INTO `equipment` (`id`, `name_equ`, `type_equ`, `serial_number`, `pic`, `status`) VALUES
(1, 'เครื่องคิดเลข 9860GII SD', 1, '0001', '1.jpg', 9),
(2, 'โต๊ะขาวพับ', 2, '0002', '2.jpg', 9),
(4, 'เครื่องเย็บกระดาษ(ใหญ่)', 2, '0003', '4.jpg', 9),
(6, 'คอมพิวเตอร์ตั้งโต๊ะ', 2, '0004', '6.jpg', 10),
(9, 'แป้นพิมพ์', 2, '0005', '9.jpg', 10),
(10, 'ชุดไมค์ลอย', 2, '0006', '10.jpg', 10),
(11, 'ลำโพง', 2, '0007', '11.jpg', 9),
(12, 'เก้าอี้', 2, '0008', '12.jpg', 9),
(13, 'macbook', 2, '0009', '13.jpg', 9),
(14, 'notebook', 2, '0010', '14.jpg', 9),
(15, 'เครื่องสแกนบาร์โค้ด', 2, '0011', '15.jpg', 10),
(17, 'คอมพิวเตอร์ตั้งโต๊ะ', 2, '00005', '17.jpg', 10),
(20, 'สายแลน', 2, 'int00011', '20.jpg', 9);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `name` varchar(100) CHARACTER SET utf8 NOT NULL,
  `student_id` varchar(20) NOT NULL,
  `mail` varchar(50) CHARACTER SET utf8 NOT NULL,
  `date_start` date NOT NULL,
  `date_end` date NOT NULL,
  `reason` varchar(500) CHARACTER SET utf8 NOT NULL,
  `project_name` varchar(100) CHARACTER SET utf8 NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `teacher_reason` varchar(500) CHARACTER SET utf8 NOT NULL,
  `status_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `name`, `student_id`, `mail`, `date_start`, `date_end`, `reason`, `project_name`, `teacher_id`, `teacher_reason`, `status_id`) VALUES
(1, 'ธนาธร  ทรงพินิจ', '6020500365', 'thanathorn.so@ku.th', '2020-03-25', '2020-03-26', 'ใช้ในโปรเจค', 'Se62_05', 10, '', 2),
(2, 'test1', '6020501370', 'test', '2020-03-11', '2020-03-18', '', '', 19, '', 2),
(3, 'test2', '6020501370', 'test', '2020-03-11', '2020-03-10', '', '', 26, '', 8),
(4, 'test3', '6020500365', 'thanathorn001@gmail.com', '2020-03-22', '2020-03-28', 'test', 'test', 10, 'test', 9),
(10, 'ธนานพ ครองชีพ', '6020501311', 'thananop.kr@ku.th', '2020-03-26', '2020-03-31', '', '', 0, ' ', 1),
(19, 'ธนานพ ครองชีพ', '6020501311', 'thananop.kr@ku.th', '2020-03-26', '2020-03-31', '', '', 0, ' ', 1),
(20, 'ธนานพ ครองชีพ', '6020501311', 'thananop.kr@ku.th', '2020-03-26', '2020-03-31', '', '', 0, ' ', 1),
(21, 'ธนานพ ครองชีพ', '6020501311', 'thananop.kr@ku.th', '2020-03-26', '2020-03-31', '', '', 0, ' ', 1),
(22, 'ธนานพ ครองชีพ', '6020501311', 'thananop.kr@ku.th', '2020-03-26', '2020-03-31', '', '', 0, ' ', 1),
(23, 'ธนาธร ทรงพินิจ', '6020500365', 'thanathorn.so@ku.th', '2020-03-26', '2020-03-27', '', '', 29, ' ', 1),
(24, 'ธนาธร ทรงพินิจ', '6020500365', 'thanathorn.so@ku.th', '2020-03-26', '2020-03-26', 'testtest', 'testtest', 29, ' ', 1),
(25, 'ธนานพ ครองชีพ', '6020501311', 'thananop.kr@ku.th', '2020-03-26', '2020-03-31', 'อยากยืมอ่ะ', 'seeiei', 50, ' ', 1),
(26, 'ธนาธร ทรงพินิจ', '6020500365', 'thanathorn.so@ku.th', '2020-03-27', '2020-03-29', 'ใช้ในการทำโปรเจค', 'SE Project', 50, ' ', 1),
(27, 'admin2', '', '', '2020-03-25', '2020-03-28', 'test', 'test', 0, ' ', 1);

-- --------------------------------------------------------

--
-- Table structure for table `order_detail`
--

CREATE TABLE `order_detail` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `equ_detail_id` varchar(20) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_detail`
--

INSERT INTO `order_detail` (`id`, `order_id`, `equ_detail_id`) VALUES
(1, 1, '1'),
(2, 1, '2'),
(3, 2, '1'),
(4, 2, '7'),
(5, 1, '4'),
(6, 1, '17'),
(7, 1, '6'),
(8, 1, '1'),
(9, 10, '2'),
(10, 10, '20'),
(11, 19, '13'),
(12, 19, '13'),
(13, 19, '15'),
(20, 23, '1'),
(21, 24, '17'),
(22, 25, '3'),
(23, 26, '1'),
(24, 27, '5'),
(25, 27, '1');

-- --------------------------------------------------------

--
-- Table structure for table `staff_teacher`
--

CREATE TABLE `staff_teacher` (
  `id` int(11) NOT NULL,
  `username` varchar(20) CHARACTER SET utf8 NOT NULL,
  `role` set('ADMIN','TEACHER','USER') NOT NULL,
  `name` varchar(100) CHARACTER SET utf8 NOT NULL,
  `email` varchar(100) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff_teacher`
--

INSERT INTO `staff_teacher` (`id`, `username`, `role`, `name`, `email`) VALUES
(33, 'fengssmt', 'TEACHER', 'อ.ดร.เสกสรรค์ มธุลาภรังสรรค์', 'fengssmt@ku.ac.th'),
(34, 'fengarp', 'TEACHER', 'ผศ.ดร.อมรฤทธิ์   พุทธิพิพัฒน์ขจร', 'fengarp@ku.ac.th'),
(35, 'fengtps', 'TEACHER', 'ผศ.ดร.ฐิติพงษ์   สถิรเมธีกุล', 'fengtps@ku.ac.th'),
(36, 'chakkrit.p', 'TEACHER', 'ผศ.ดร.จักกริช พฤษการ', 'chakkrit.p@ku.ac.th'),
(37, 'fengncn', 'TEACHER', 'ผศ.นุชนาฎ   สัตยากวี', 'fengncn@ku.ac.th'),
(38, 'fengsds', 'TEACHER', 'อ.ดร.ศิวดล เสถียรพัฒนากูล', 'fengsds@ku.ac.th'),
(39, 'fengame', 'TEACHER', 'อ.ร้อยโทอนุมัติ อิงคนินันท์', 'fengame@ku.ac.th'),
(40, 'fengvry', 'TEACHER', 'อ.ดร.วรัญญา  อรรถเสนา', 'fengvry@ku.ac.th'),
(41, 'fengbyr', 'TEACHER', 'อ.ดร.บุญรัตน์  เผดิมรอด', 'fengbyr@ku.ac.th'),
(42, 'fengpcsu', 'TEACHER', 'อ.ดร.พิเชษฐ์  สืบสายพรหม', 'fengpcsu@ku.ac.th'),
(43, 'fengkrj@ku.ac.th', 'TEACHER', 'อ.ดร.กายรัฐ  เจริญราษฎร์', 'fengkrj@ku.ac.th'),
(44, 'fengdpj', 'TEACHER', 'ผศ.ดร.ดวงเพ็ญ  เจตน์พิพัฒนพงษ์', 'fengdpj@ku.ac.th'),
(45, 'fengjts@ku.ac.th', 'ADMIN', 'น.ส.จุฑาทิพย์  ทรัพย์ฤทธา', 'fengjts@ku.ac.th'),
(46, 'fengsstc', 'ADMIN', 'น.ส.ศศิธร   ชลรัตน์อมฤต', 'fengsstc@ku.ac.th'),
(47, 'fengmcn', 'ADMIN', 'น.ส.มณฑิชา กิจสมสาตร์', 'fengmcn@ku.ac.th'),
(48, 'fengalr', 'ADMIN', 'นายเอกลักษณ์ เรืองศรี', 'fengalr@ku.ac.th'),
(49, 'fengsok', 'ADMIN', 'นายวรธนัท เกตุศิริ', 'fengsok@ku.ac.th'),
(50, 'test', 'TEACHER', 'นายธนาธร  ทรงพินิจ', 'thanathorn.so@ku.th');

-- --------------------------------------------------------

--
-- Table structure for table `status_order`
--

CREATE TABLE `status_order` (
  `id` int(11) NOT NULL,
  `name` varchar(50) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `status_order`
--

INSERT INTO `status_order` (`id`, `name`) VALUES
(1, 'รอการอนุมัติ'),
(2, 'อนุมัติ'),
(3, 'ไม่อนุมัติ'),
(4, 'รอรับของ'),
(5, 'ยืมอยู่'),
(6, 'ถึงกำหนดวันคืน'),
(7, 'เลยกำหนดวันคืน'),
(8, 'คืนแล้ว'),
(9, 'ยืมได้'),
(10, 'ยืมไม่ได้'),
(11, 'ยกเลิกการยืม');

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `id` int(11) NOT NULL,
  `equ_id` int(11) NOT NULL,
  `total` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`id`, `equ_id`, `total`) VALUES
(1, 1, 2),
(2, 2, 2),
(3, 4, 2),
(4, 6, 2),
(5, 9, 2),
(6, 10, 2),
(7, 11, 2),
(8, 12, 2),
(9, 13, 2),
(10, 14, 2),
(11, 15, 1);

-- --------------------------------------------------------

--
-- Table structure for table `test`
--

CREATE TABLE `test` (
  `id` int(11) NOT NULL,
  `equ_id` int(11) NOT NULL,
  `count` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `test`
--

INSERT INTO `test` (`id`, `equ_id`, `count`) VALUES
(1, 1, 3),
(2, 6, 10),
(3, 4, 50);

-- --------------------------------------------------------

--
-- Table structure for table `type`
--

CREATE TABLE `type` (
  `id` int(11) NOT NULL,
  `type_name` varchar(50) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `type`
--

INSERT INTO `type` (`id`, `type_name`) VALUES
(1, 'อุปกรณ์สำนักงาน'),
(2, 'อุปกรณ์อิเล็กทรอนิกส์'),
(5, 'อุปกรณ์ทั่วไป'),
(32, 'อุปกรณ์ทำความสะอาด');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `uid` int(11) NOT NULL,
  `user` varchar(30) CHARACTER SET utf8 NOT NULL,
  `pass` varchar(200) CHARACTER SET utf8 NOT NULL,
  `role` set('ADMIN','USER','TEACHER') CHARACTER SET utf8 NOT NULL DEFAULT 'USER'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`uid`, `user`, `pass`, `role`) VALUES
(2, 'admin', '$2y$10$jHQxxjasuVjlzPONZ0pVpe5G1gwkltcAKNFdm9nnkRZ6bqRnLfG4.', 'ADMIN'),
(3, 'feng', '$2y$10$FR0uHvYrF8mUHJ3VXVNwjeY8iwuTajAGPs2IdykY509BnRSuyJyA2', 'TEACHER'),
(6, 'test', '$2y$10$D9YUpiupkMKCAXCO3SxqUuw1JqSV8OuMJZg1DLjHujNh9jIh4jRTm', 'ADMIN'),
(10, 'admin2', '$2y$10$In.eu8EHYxoUPbi3ngJeuudzJdl3uUIMfaIL5UczbsJ.qyUfHrd1e', 'TEACHER');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `date_cancel`
--
ALTER TABLE `date_cancel`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `equiment_detail`
--
ALTER TABLE `equiment_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `equipment`
--
ALTER TABLE `equipment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_detail`
--
ALTER TABLE `order_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `staff_teacher`
--
ALTER TABLE `staff_teacher`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `status_order`
--
ALTER TABLE `status_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `test`
--
ALTER TABLE `test`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `type`
--
ALTER TABLE `type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `date_cancel`
--
ALTER TABLE `date_cancel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `equiment_detail`
--
ALTER TABLE `equiment_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT for table `equipment`
--
ALTER TABLE `equipment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT for table `order_detail`
--
ALTER TABLE `order_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `staff_teacher`
--
ALTER TABLE `staff_teacher`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;
--
-- AUTO_INCREMENT for table `status_order`
--
ALTER TABLE `status_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `stock`
--
ALTER TABLE `stock`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `test`
--
ALTER TABLE `test`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `type`
--
ALTER TABLE `type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
