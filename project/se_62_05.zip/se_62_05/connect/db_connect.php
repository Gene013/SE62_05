<?php
$servername = "localhost";
$username = "se62_05";
$password = "se62_05";
$dbname = "se62_05";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
mysqli_set_charset($conn,"utf8");
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}else{
    //echo "Connected successfully";
}
?>