<?php
session_start();

if (isset($_SESSION["Logon"]) && $_SESSION["Logon"] == 1) {
    $ldap_uid = $_SESSION["ldap_uid"];
    $ldap_engname = $_SESSION["ldap_engname"];
    $ldap_thainame = $_SESSION["ldap_thainame"];
    $ldap_email = $_SESSION["ldap_email"];
    $ldap_gender = $_SESSION["ldap_gender"];
    $ldap_Job = $_SESSION["ldap_Job"];
    $ldap_position = $_SESSION["ldap_position"];
    $ldap_department = $_SESSION["ldap_department"];
    $ldap_faculty = $_SESSION["ldap_faculty"];
    $ldap_campus = $_SESSION["ldap_campus"];
    $ldap_Status = $_SESSION["ldap_Status"];
    $ldap_idcode = $_SESSION["ldap_idcode"];
} elseif (isset($_SESSION["Logon"]) && $_SESSION["Logon"] == 2) {
    $ldap_thainame = $_SESSION["ldap_thainame"];
    $ldap_Status = $_SESSION["ldap_Status"];
}else{
    header('location:form_login.php');
}
?>
<div class="container-fluid" align="center">
                <div>
                    <br>
                    <h2 align = 'center'>รายการอุปกรณ์</h2>
                    <br>
                </div>
                <div class="container p-3 my-3 border" style="-webkit-box-flex: 0;
      -ms-flex: 0 0 calc(100% - 10px);
      flex: 0 0 calc(100% - 10px);
      max-width: calc(100% - 10px);
      width: calc(100% - 10px); } }">
                    <div class="row">
                        <?php foreach($equipList as $equip){echo "
                        <div class='col-sm-4'>
                            <img src='img/equipment/$equip->pic' class='card-img-top' width='460' height='260'>
                            <script>console.log('$equip->pic')</script>
                            <div class='card-body'>
                                <h6 class='card-title'>$equip->name</h6>
                                <p class='card-text'>$equip->type</p> ";
                                if($equip->status==10){
                                    echo "<a style='color: red'>ยืมไม่ได้</a><br><br>";
                                }else{
                                    echo "<a style='color: green'>ยืมได้</a><br><br>";
                                }
                                echo "
                                <form method='post' action='index.php?controller=pages&action=detail' >
                                    <input type='hidden' name='equ_id' value='$equip->id'>
                                    <input type='hidden' name='equ_name' value='$equip->name'>
                                    <input type='hidden' name='equ_type' value='$equip->type'>
                                    <input type='hidden' name='equ_pic' value='$equip->pic'>
                                    <input type='hidden' name='equ_serial' value='$equip->serial'>
                                    <input type='hidden' name='equ_status' value='$equip->status'>
                                 <button class='btn btn-primary' type='submit'>รายละเอียด</a>
                                   </form>";
                                echo "
                            </div>
                        </div> ";}?>
                    </div>
                </div>
            </div>
