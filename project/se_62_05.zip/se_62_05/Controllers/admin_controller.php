<?php
session_start();

class AdminController{
    public  function addEquipment(){
        $typeList = type::getAll();
        require_once ('Views/admin/add_equipment.php');
    }

    public  function edit_detail(){
        $equipList = equipment::getAll();
        $typeList = type::getAll();
        require_once ('Views/admin/edit_detail.php');
    }

    public  function set_date_cancel(){
        require_once ('Views/admin/set_date_cancel.php');
    }

    public  function editDate(){
        $id = $_POST['id'];
        $num = $_POST['num'];
        require('connect/db_connect.php');
        $sql = 'UPDATE date_cancel SET num_date="'.$num.'" WHERE date_cancel.id="'.$id.'"';
        if($result = mysqli_query($conn,$sql)){
            echo "<script>console.log('update success')</script>";
        }else{
            echo "<script>console.log('update fail')</script>";
        }
        require('connect/db_connect.php');
        require_once ('pages_controller.php');
        PagesController::home();
    }

    public function editType(){
        $id = $_POST['id'];
        $type_name = $_POST['type_name'];
        type::editType($id,$type_name);
        require_once ('pages_controller.php');
        PagesController::home();
    }

    public function addT(){

        require_once ('Views/admin/addType.php');
        }

    public function addType(){
        $type_name = $_POST['type_name'];
        type::addType($type_name);
        AdminController::ManageType();
    }
    
    public  function statistics(){

        require_once ('Views/admin/statistics.php');
    }

    public  function statistics_month(){

        require_once ('Views/admin/statistics_month.php');
    }

    public  function statistics_year(){

        require_once ('Views/admin/statistics_year.php');
    }

    public  function editEquip(){
        $id = $_POST['id'];
        $name = $_POST['name'];
        $type = $_POST['type'];
        $serial = $_POST['serial'];
        $status = $_POST['status'];

        echo "<script>console.log($id)</script>";
        echo "<script>console.log($name)</script>";
        echo "<script>console.log($type)</script>";
        echo "<script>console.log($serial)</script>";
        echo "<script>console.log($status)</script>";

        equipment::editEquipment($id,$name,$type,$serial,$status);
        require_once ('pages_controller.php');
        PagesController::home();


           }
    public  function deleteEqu(){
        $id = $_POST['id'];
        echo "<script>console.log($id)</script>";
        equipment::deleteEquipment($id);
        require_once ('pages_controller.php');
        PagesController::home();


    }

    public  function addEquip(){
        $name = $_POST['name'];
        $type = $_POST['type'];
        $serial = $_POST['serial'];
        $status = $_POST['status'];
        $file = $_FILES['inputFile'];
        $cart = $_SESSION['cart'];
        echo "<script>console.log('type$type')</script>";
        $filename = equipment::addEquipment($name,$type,$serial,$file,$status,$cart);
        echo "<script>console.log('$filename')</script>";
        $aaaa = $_FILES['inputFile']['tmp_name'];
        echo "<script>console.log('$aaaa')</script>";
        if(move_uploaded_file($_FILES['inputFile']['tmp_name'],$filename)){
            echo "<script>console.log('สำเร็จ')</script>";
        }
        else{
            echo "<script>console.log('มีปัญหา')</script>";
        }
        $bool1 = true;
        echo "<script>console.log('$bool1')</script>";
        AdminController::addEquipment();
    }

    public function ManageUser(){
        $UserList = teacher::getUserAll();
        require_once ('Views/admin/ManageUser.php');
    }

    public function editUser(){
        $UserList = teacher::getUserAll();
        require_once ('Views/admin/editUser.php');
    }

    public function addEditUser(){
        $id = $_POST['id'];
        $username = $_POST['username'];
        $name = $_POST['name'];
        $mail = $_POST['mail'];
        $role = $_POST['role'];
        teacher::addEditUser($id,$username,$name,$mail,$role);
        AdminController::ManageUser();
    }

    public static function formUser(){
        require_once ('Views/admin/formUser.php');
    }

    public static function addUser(){
        $username = $_POST['username'];
        $name = $_POST['name'];
        $mail = $_POST['mail'];
        $role = $_POST['role'];
        teacher::addUser($username,$name,$mail,$role);
        AdminController::ManageUser();
    }

    public static function removeUser(){
        $id = $_GET['u'];
        teacher::removeUser($id);
        AdminController::ManageUser();
    }

    public  static function ManageType(){
        $typeList = type::getAll();
        require_once ('Views/admin/ManageType.php');
    }

    public  static function edittType(){
        $typeList = type::getAll();
        require_once ('Views/admin/editType.php');
    }

    public static function addEditType(){
        $id = $_POST['id'];
        $type_name = $_POST['type_name'];
        echo "<script>console.log('$id')</script>";
        echo "<script>console.log('$type_name')</script>";
        type::editType($id,$type_name);
        AdminController::ManageType();
    }

    public static function removeType(){
        $id = $_GET['u'];
        type::removeType($id);
        AdminController::ManageType();
    }

    public static function ManageUserExternal(){
        $userList = user::getAll();
        require_once ('Views/admin/ManageUserExternal.php');
    }

    public static function addUserE(){
        $user = $_POST['user'];
        $pass = $_POST['pass'];
        $role = $_POST['role'];
        user::addUser($user,$pass,$role);
        AdminController::ManageUserExternal();
    }

    public static function removeUserE(){
        $id = $_POST['id'];
        user::delUser($id);
        echo "<script>console.log('$id')</script>";
        AdminController::ManageUserExternal();
    }
}
?>